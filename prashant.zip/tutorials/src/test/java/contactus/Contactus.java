package contactus;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class Contactus 
{
	WebDriver driver;
	@Test
	public void contact() throws IOException, InterruptedException 
	{

		File f = new File ("D:\\Finaltutorialsninja\\Data\\SignaUp.xlsx");
		FileInputStream fis =new FileInputStream(f);
		XSSFWorkbook wk = new XSSFWorkbook(fis);
		XSSFSheet sh= wk.getSheet("Sheet8");


		int size= sh.getLastRowNum();

		for (int i=0; i<=size; i++)
		{ 
		driver.findElement(By.xpath("/html[1]/body[1]/footer[1]/div[1]/div[1]/div[2]/ul[1]/li[1]/a[1]")).click();
		
		

		WebElement fname= driver.findElement(By.id("input-name"));
		WebElement email= driver.findElement(By.id("input-email"));
		WebElement enq= driver.findElement(By.id("input-enquiry"));

		
			

			String fn= sh.getRow(i).getCell(0).toString();
			String em= sh.getRow(i).getCell(1).toString();
			String en= sh.getRow(i).getCell(2).toString();
			
             fname.sendKeys(fn);
			email.sendKeys(em);
			enq.sendKeys(en);
			Thread.sleep(3000);
			driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[1]/input[1]")).click();
			
			try
			{

				
				driver.findElement(By.linkText("Continue")).click();
				

			}
			catch(Exception e)
			{
				System.out.print("---- Invalid email ");
			}
			 

			
		}
		
        


	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://tutorialsninja.com/demo/index.php?route=common/home");
	}

	@AfterTest
	public void afterTest() 
	{
		driver.close();
	}

}
